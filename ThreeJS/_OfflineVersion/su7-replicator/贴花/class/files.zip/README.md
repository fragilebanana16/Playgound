# DecalManager - Three.js 贴花管理器

一个用于在Three.js中轻松管理贴花（Decal）的类库。

## 功能特性

- ✨ 简单易用的API
- 🎯 自动射线检测和贴花放置
- 🎨 支持自定义贴花材质和纹理
- 🔧 可配置的贴花大小和旋转
- 🧹 方便的贴花管理（添加、删除、清空）
- 🎮 与OrbitControls完美集成
- 👁️ 可视化辅助工具（鼠标位置、法线方向）

## 快速开始

### 1. 引入依赖

```html
<script src="three.min.js"></script>
<script src="OrbitControls.js"></script>
<script src="DecalGeometry.js"></script>
<script src="DecalManager.js"></script>
```

### 2. 创建实例

```javascript
const decalManager = new DecalManager(scene, camera, renderer.domElement, {
    minScale: 10,           // 最小贴花尺寸
    maxScale: 20,           // 最大贴花尺寸
    rotate: true,           // 是否随机旋转
    decalDiffuseUrl: 'textures/decal-diffuse.png',
    decalNormalUrl: 'textures/decal-normal.jpg'
});
```

### 3. 设置目标网格

```javascript
// 加载模型后设置
loader.load('model.glb', function(gltf) {
    const mesh = gltf.scene.children[0];
    scene.add(mesh);
    
    // 设置为贴花目标
    decalManager.setTargetMesh(mesh);
});
```

### 4. 与OrbitControls集成（可选）

```javascript
const controls = new THREE.OrbitControls(camera, renderer.domElement);

controls.addEventListener('change', function() {
    decalManager.markAsMoved();
});
```

## API 文档

### 构造函数

```javascript
new DecalManager(scene, camera, domElement, options)
```

**参数：**
- `scene` (THREE.Scene) - Three.js场景对象
- `camera` (THREE.Camera) - Three.js相机对象
- `domElement` (HTMLElement) - 用于监听鼠标事件的DOM元素
- `options` (Object) - 配置选项

**配置选项：**
```javascript
{
    minScale: 10,          // 贴花最小尺寸
    maxScale: 20,          // 贴花最大尺寸
    rotate: true,          // 是否随机旋转贴花
    decalDiffuseUrl: '',   // 贴花漫反射纹理路径
    decalNormalUrl: ''     // 贴花法线纹理路径
}
```

### 主要方法

#### setTargetMesh(mesh)
设置要应用贴花的目标网格。

```javascript
decalManager.setTargetMesh(mesh);
```

#### addDecal(customOptions)
在当前鼠标交点位置添加贴花。

```javascript
// 添加随机颜色贴花
decalManager.addDecal();

// 添加指定颜色的贴花
decalManager.addDecal({ color: 0xff0000 });
```

#### clearDecals()
清除所有贴花。

```javascript
decalManager.clearDecals();
```

#### removeDecal(decal)
移除指定的贴花。

```javascript
const decal = decalManager.addDecal();
decalManager.removeDecal(decal);
```

#### setParams(params)
更新配置参数。

```javascript
decalManager.setParams({
    minScale: 15,
    maxScale: 25,
    rotate: false
});
```

#### getParams()
获取当前配置参数。

```javascript
const params = decalManager.getParams();
console.log(params.minScale); // 10
```

#### setHelperVisible(visible)
显示或隐藏辅助工具（鼠标位置指示器和法线方向线）。

```javascript
decalManager.setHelperVisible(true);  // 显示
decalManager.setHelperVisible(false); // 隐藏
```

#### markAsMoved()
标记为已移动状态。用于与OrbitControls配合，避免在旋转视角时误触发贴花添加。

```javascript
controls.addEventListener('change', () => {
    decalManager.markAsMoved();
});
```

#### dispose()
销毁管理器，清理所有资源和事件监听器。

```javascript
decalManager.dispose();
```

## 完整示例

```javascript
// 初始化场景
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });

renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// 创建控制器
const controls = new THREE.OrbitControls(camera, renderer.domElement);

// 创建贴花管理器
const decalManager = new DecalManager(scene, camera, renderer.domElement, {
    minScale: 5,
    maxScale: 15,
    rotate: true
});

// OrbitControls集成
controls.addEventListener('change', () => {
    decalManager.markAsMoved();
});

// 加载模型
const loader = new THREE.GLTFLoader();
loader.load('model.glb', (gltf) => {
    const mesh = gltf.scene.children[0];
    scene.add(mesh);
    decalManager.setTargetMesh(mesh);
});

// 渲染循环
function animate() {
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();

// 清理
window.addEventListener('beforeunload', () => {
    decalManager.dispose();
});
```

## 使用技巧

### 1. 自定义贴花材质

如果需要更复杂的材质效果，可以直接修改类中的 `decalMaterial` 属性：

```javascript
decalManager.decalMaterial.metalness = 0.5;
decalManager.decalMaterial.roughness = 0.3;
```

### 2. 程序化添加贴花

虽然默认通过鼠标点击添加，但你也可以程序化地添加贴花：

```javascript
// 首先需要手动设置intersection信息
decalManager.intersection.intersects = true;
decalManager.intersection.point.set(x, y, z);
decalManager.intersection.normal.set(nx, ny, nz);

// 然后添加贴花
decalManager.addDecal({ color: 0x00ff00 });
```

### 3. 响应式设计

记得在窗口大小改变时更新相机：

```javascript
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
```

### 4. 性能优化

如果贴花数量很多，可以考虑：
- 限制最大贴花数量
- 定期清理旧的贴花
- 使用更低分辨率的纹理

```javascript
// 限制贴花数量
const MAX_DECALS = 100;

const originalAddDecal = decalManager.addDecal.bind(decalManager);
decalManager.addDecal = function(options) {
    if (this.decals.length >= MAX_DECALS) {
        this.removeDecal(this.decals[0]); // 移除最早的贴花
    }
    return originalAddDecal(options);
};
```

## 注意事项

1. 确保目标网格已正确加载后再调用 `setTargetMesh()`
2. 贴花的Z-fighting可以通过调整 `polygonOffsetFactor` 解决
3. 使用完毕后记得调用 `dispose()` 方法清理资源
4. DecalGeometry需要目标网格有正确的几何体和法线信息

## 浏览器兼容性

支持所有现代浏览器，需要WebGL支持。

## 依赖

- Three.js (r128+)
- DecalGeometry (Three.js示例)
- OrbitControls (可选，用于相机控制)

## License

MIT

## 贡献

欢迎提交问题和拉取请求！
